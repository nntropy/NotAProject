<?php
require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");
$restaurantController = new RestaurantController();
$content = 'Successfully edited!';
$sidebar = '';
$title = 'Info edited!';

if(isset($_GET['AddRestaurant'])) {
    addRestaurant();
}
if(isset($_GET['CAccount'])) {
    addUser();
}
if(isset($_GET['AddItem'])) {
    addItem();
}
if(isset($_GET['RemoveRestaurant'])) {
    removeRestaurant();
}
if(isset($_GET['RemoveItem'])) {
    removeItem();
}
if(isset($_GET['DeleteAccount'])) {
    removeUser();
}
if(isset($_GET['ChooseResto'])) {
    $name = $_GET['restaurant'];
    $content = "<form action = 'EditingInfo.php' method='GET'>". "<input type=\"hidden\" name='name' value='$name'". $restaurantController->CreateEditDropdownList('menu') .
        "<br> <input type = 'submit' value = 'Delete' name = 'RemoveItem'></form>";
}
function getMaxRestaurant() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");

    $query = "SET search_path = Project;
               SELECT MAX(R.RESTAURANT_ID)
               FROM RESTAURANT AS R";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());

    $val1 = 0;

    while($row = pg_fetch_array($result)) {
        $val1 = $row[0];
    }

    //close connection
    pg_close($dbconn);
    return ((int)$val1)+1;
}

function getMaxUser() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");

    $query = "SET search_path = Project;
               SELECT MAX(R.USER_ID)
               FROM RATER AS R";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());

    $val1 = 0;

    while($row = pg_fetch_array($result)) {
        $val1 = $row[0];
    }

    //close connection
    pg_close($dbconn);
    return ((int)$val1)+1;
}

function getMaxMenuItem() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");

    $query = "SET search_path = Project;
               SELECT MAX(M.ITEM_ID)
               FROM MENUITEM AS M";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());

    $val1 = 0;

    while($row = pg_fetch_array($result)) {
        $val1 = $row[0];
    }

    //close connection
    pg_close($dbconn);
    return ((int)$val1)+1;
}

function getRestaurantID($name)
{
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $conn_string = 'host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn = pg_connect($conn_string) or die("Connection failed");
    $query = "SET search_path=Project;
                  SELECT R.RESTAURANT_ID
                  FROM Restaurant AS R
                  WHERE R.ANAME LIKE '$name'";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());

    $val1 = 0;

    while($row = pg_fetch_array($result)) {
        $val1 = $row[0];
    }

    //close connection
    pg_close($dbconn);
    return $val1;
}

function addRestaurant() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $max = getMaxRestaurant();
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");

    $query = "SET search_path = Project;
               INSERT INTO RESTAURANT
               VALUES( '" . $max . "','" . $_GET['RName'] . "','" . $_GET['type'] . "','" . $_GET['URL'] . "')";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}

function removeRestaurant() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $restaurantName = $_GET['restaurant'];
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");
    $query = "SET search_path = Project;
              DELETE FROM RESTAURANT
              WHERE RESTAURANT.ANAME = '$restaurantName'";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}



function addItem() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $maxItem = getMaxMenuItem();
    $restaurantID = getRestaurantID($_GET['restaurant']);
    $dbconn =pg_connect($conn_string) or die("Connection failed");
    $query = "SET search_path = Project;
               INSERT INTO MENUITEM
               VALUES('" . $maxItem . "','" . $_GET['Name'] . "','" . $_GET['Type'] . "','" . $_GET['Category'] . "','" . $_GET['Description'] . "','" . $_GET['Price'] . "','" . $restaurantID . "')";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}


function removeItem() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $item = $_GET['type'];
    $restaurant = $_GET['name'];
    $restuarantID = getRestaurantID($restaurant);
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");
    $query = "SET search_path = Project;
               DELETE FROM MENUITEM
               WHERE MENUITEM.ANAME = '$item' AND MENUITEM.RESTAURANT_ID = '$restuarantID'";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}

function addUser() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $max = getMaxUser();
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");

    $query = "SET search_path = Project;
               INSERT INTO RATER
               VALUES( '" . $max . "','" . $_GET['CEmail'] . "','" . $_GET['fullname'] . "','2018-04-09','" . $_GET['CType'] . "','1')";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}

function removeUser() {
    require 'C:\Users\aidanocc\Mitchell\Model/Credentials.php';
    $userID = $_GET['userID'];
    $conn_string='host= localhost port=5432 dbname=project user=postgres password=Flashfire37!';
    $dbconn =pg_connect($conn_string) or die("Connection failed");
    $query = "SET search_path = Project;
              DELETE FROM RATER
              WHERE RATER.ANAME = '$userID'";
    $result=pg_query($dbconn,$query) or die("Error in SQL query: ".pg_last_error());
}












include 'Template.php'; ?>