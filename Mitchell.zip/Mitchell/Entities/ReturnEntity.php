<?php

class ReturnEntity {
    public $val1;
    public $val2;
    public $val3;
    public $val4;
    public $val5;
    public $val6;
    public $val7;
    public $val8;
    public $val9;
    public $val10;
    public $val11;
    public $val12;
    public $val13;
    public $val14;
    public $val15;
    function ReturnEntity($val1, $val2, $val3, $val4, $val5, $val6, $val7, $val8, $val9, $val10, $val11, $val12, $val13, $val14, $val15) {
        $this-> val1 = $val1;
        $this-> val2 = $val2;
        $this-> val3 = $val3;
        $this-> val4 = $val4;
        $this-> val5 = $val5;
        $this-> val6 = $val6;
        $this-> val7 = $val7;
        $this-> val8 = $val8;
        $this-> val9 = $val9;
        $this-> val10 = $val10;
        $this-> val11 = $val11;
        $this-> val12 = $val12;
        $this-> val13 = $val13;
        $this-> val14 = $val14;
        $this-> val15 = $val15;

    }
}
?>