<?php

//Login data for the database. Use this file in all Models
$host = 'jdbc:postgresql://www.eecs.uottawa.ca:15432/mchat022?currentSchema=Project';
$port = '15432';
$user = 'mchat022';
$passwd = 'M2rnay6gz9';
$database = 'Project';
$conn_string='host=www.eecs.uottawa.ca port=15432 dbname=mchat022 user=mchat022 password=M2rnay6gz9';
$search_path='mchat022."Project".';
?>