<?php
require_once ("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");

$name = $_GET['Restaurant'];
$title = $name . 'Menu';
$restaurantController = new RestaurantController();

$content = $restaurantController->CreateQueryB('%');
$sidebar = '';



include 'Template.php';


?>