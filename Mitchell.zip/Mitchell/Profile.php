<?php
/**
 * Created by IntelliJ IDEA.
 * User: aidanocc
 * Date: 2018-04-09
 * Time: 7:06 AM
 */
$user = $_GET['username'];
$title = $user;
$currentPassword = $_GET['password'];
$sidebar = '';
$content = "
<fieldset name='types'>
   Edit account info: <br> <br>
    Username: <br>
  <form action = 'EditingInfo.php' method='GET'>
    <input type='text' name='Username'> <br>
    Current password: <br> 
    <input type='text' name='OldPass'> <br>
    New password:  <br>
    <input type='text' name='NewPass'> <br>
    <input type = 'submit' value = 'Edit' name = 'changeAccInfo'>
  </form>
</fieldset>
<fieldset name='types'>
<form action = 'EditingInfo.php' method='GET'>
    Delete Account: <br> <br>
    Full Name: <br>
    <input type='text' name='userID' <br> <br>
    <input type = 'submit' value = 'Delete' name = 'DeleteAccount'>
</form>
</fieldset>
";

include 'Template.php';
?>