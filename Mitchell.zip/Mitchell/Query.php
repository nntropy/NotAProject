<?php
require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");

$restaurantController = new RestaurantController();
$title = 'Query!';
$content = "<fieldset name='types'>";

if (isset($_GET['restaurant']) OR $_GET['Query'] == 'A' OR $_GET['Query'] == 'B' OR $_GET['Query'] == 'D') {
    if(isset($_GET['restaurant'])) {
        if (isset($_GET['A'])) {
            $content .= $restaurantController->CreateQueryA($_GET['restaurant']);
        }
        if (isset($_GET['D'])) {
            $content .= $restaurantController->CreateQueryD($_GET['restaurant']);
        }
        else {
            $content .= $restaurantController->CreateQueryB($_GET['restaurant']);
        }
    }
    else {
        $content = "Select a restaurant:
                <fieldset name='types'><form action = 'Query.php' method = 'GET'> 
                    " . $restaurantController->CreateEditDropdownList('names') . "
                <input type='submit' name=" . $_GET['Query'] . ">
                </form> </fieldset>";
    }

}
else if(isset($_GET['type']) OR $_GET['Query'] == 'C' OR $_GET['Query'] == 'D') {
    if(isset($_GET['type'])) {
        $content .= $restaurantController->CreateQueryC($_GET['type']);
    }
    else {
        $content = "Select a restaurant type:
                <fieldset name='types'><form action = 'Query.php' method = 'GET'> 
                    " . $restaurantController->CreateEditDropdownList('types') . "
                <input type='submit' name=" . $_GET['Query'] . ">
                </form></fieldset>";
    }
}
else {
    $content .= $restaurantController->MasterQueryCreator($_GET['Query']);
}

$content .= "</fieldset>";
$sidebar = "Query " . $_GET['Query'];

include 'Template.php';
?>