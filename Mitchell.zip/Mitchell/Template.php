

<!DOCTYPE html>
<?php require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");
      $restaurantController= new RestaurantController();?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" />
</head>
<body>
<div id="wrapper">
    <div id="banner">
    </div>
    <nav id="navigation">
        <ul id="nav">
            <li><a href="index.php">Home</a></li>
            <li><div class="dropdown">
                <button onclick="myFunction()" class="dropbtn">Queries</button>
                <div id="myDropdown" class="dropdown-content">
                    <a href="Query.php?Query=A">Query A</a>
                    <a href="Query.php?Query=B">Query B</a>
                    <a href="Query.php?Query=C">Query C</a>
                    <a href="Query.php?Query=D">Query D</a>
                    <a href="Query.php?Query=E">Query E</a>
                    <a href="Query.php?Query=F">Query F</a>
                    <a href="Query.php?Query=G">Query G</a>
                    <a href="Query.php?Query=H">Query H</a>
                    <a href="Query.php?Query=I">Query I</a>
                    <a href="Query.php?Query=J">Query J</a>
                    <a href="Query.php?Query=K">Query K</a>
                    <a href="Query.php?Query=L">Query L</a>
                    <a href="Query.php?Query=M">Query M</a>
                    <a href="Query.php?Query=N">Query N</a>
                    <a href="Query.php?Query=O">Query O</a>

                </div>
                </div></li>
            <li><div class="dropdown">
                <button onclick="myFunction2()" class="dropbtn2">Edit Info</button>
                <div id="myDropdown2" class="dropdown-content2">
                    <a href="editInfo.php?Edit=Menu">Edit Menu</a>
                    <a href="editInfo.php?Edit=Restaurants">Edit Restaurants</a>
                </div>
                </div></li>
            <!-- Trigger/Open The Modal -->
            <li><button id="cAccount" onclick="document.getElementById('myModal').style.display='block'" style="width:auto;">Login</button></li>
            <li><button id="cLogin" onclick="document.getElementById('myModal2').style.display='block'" style="width:auto;">Create Account</button></li>
            <!-- The Modal -->
                <div id="myModal" class="modal">
                    <div class="Login">
                        <form action = 'Profile.php' method='GET'>
                        <span class="close" onclick="document.getElementById('myModal').style.display='block'">&times;</span>
                        <input type="text" placeholder="Username" id="username" name="username">
                        <input type="password" placeholder="password" id="password" name="password">
                        <button id = "changeToCAccount" onclick="document.getElementById('myModal').style.display='none'; document.getElementById('myModal2').style.display='block'" style="width:auto;">create an account</button>
                        <a href="#" class="forgot">forgot password?</a>
                        <input type="submit" id="submitLogin" value="Sign In" name = "CLogin">
                        </form>
                    </div>
                </div>
                <div id="myModal2" class="modal">
                    <div class="createAccount">
                        <form action = 'EditingInfo.php' method='GET'>
                        <span class="close" onclick="document.getElementById('myModal2').style.display='block'">&times;</span>
                        <input type="text" placeholder="Full Name" id="FN" name="fullname">
                        <input type="text" placeholder="Email" id="username" name="CEmail">
                        <input type="text" placeholder="Type" id="password" name="CType">
                        <button id="switchToLogin" onclick="document.getElementById('myModal2').style.display='none'; document.getElementById('myModal').style.display='block'" style="width:auto;">Login</button>
                        <p id="switchToLoginTXT" style="font-size:12px; float: left; padding-left:80px; padding-right: 5px;">Already have an account?</p>
                        <input type="submit" id="submitCAccount" value="Create Account" name = "CAccount">
                        </form>
                    </div>
                </div>

        </ul>
    </nav>

    <div id="content_area">
        <?php
        echo $content;
        ?>
    </div>

    <div id="sidebar">
        <?php
        echo $sidebar
        ?>
    </div>

    <footer>
        <p>All rights reserved</p>
    </footer>
</div>


<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    //Get modal 2
    var modal2 = document.getElementById('myModal2');

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    var span2 = document.getElementsByClassName("close")[1];

    // Get the submit button
    var submit = document.getElementById('submitLogin');

    // Get the create account button
    var createAccount = document.getElementById('submitCAccount');

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    };

    span2.onclick = function() {
        modal2.style.display = 'none';
    };

    createAccount.onclick = function() {
        modal2.style.display = "none";

    };


    // When user clicks on submit, creates a query
    submit.onclick = function() {
        modal.style.display = "none";
    };

    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    function myFunction2() {
        document.getElementById("myDropdown2").classList.toggle("show2");
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
        if (event.target == modal2) {
            modal2.style.display = "none";
        }
        if (!event.target.matches('.dropbtn')) {

            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
        if (!event.target.matches('.dropbtn2')) {

            var dropdowns2 = document.getElementsByClassName("dropdown-content2");
            var i2;
            for (i2 = 0; i2 < dropdowns2.length; i2++) {
                var openDropdown2 = dropdowns2[i2];
                if (openDropdown2.classList.contains('show2')) {
                    openDropdown2.classList.remove('show2');
                }
            }
        }
    };

</script>
</body>
</html>
