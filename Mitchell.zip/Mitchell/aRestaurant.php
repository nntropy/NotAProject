<?php
require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");
$name = $_GET['Restaurant'];
$title = $name;
$restaurantController = new RestaurantController();

$content = "<fieldset name='types'>" . $restaurantController->CreateQueryA($name) . "</fieldset>";
$sidebar = '';



include 'Template.php';
?>