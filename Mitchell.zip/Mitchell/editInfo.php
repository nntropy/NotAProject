<?php
require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");
$type = $_GET['Edit'];
$title = 'Edit info';
$restaurantController = new RestaurantController();
$restaurantModel = new restaurantModel();
if($type == 'Menu') {
    $content = "
<fieldset name='types'>
Adding an item:
    <br>
  <form action = 'EditingInfo.php' method='GET'>"
        . $restaurantController->CreateEditDropdownList('names') . "<br>
    Item Information:<br>
  Item Name: <br>
  <input type='text' name='Name'> <br> <br>
  Item Type: <br>
  <input type='text' name='Type'> <br>
  Item Category: <br>
  <input type='text' name='Category'> <br>
  Item Description: <br>
  <input type='text' name='Description'> <br>
  Price:  <br>
  <input type='text' name='Price'> <br>
  <input type = 'submit' value = 'Add' name = 'AddItem'>
</form></fieldset>
<fieldset name='types'>
Removing an item: <br>
    <br>
   <form action = 'EditingInfo.php' method='GET'>"
        . $restaurantController->CreateEditDropdownList('names') . "
   <br> <input type = 'submit' value = 'Select' name = 'ChooseResto'> <br>
   </form></fieldset>";
}
else if ($type == 'Restaurants') {
    $content = "
<fieldset name='types'>
Adding a Restaurant:
<form action = 'EditingInfo.php' method='GET' name='userform'>
    Restaurant Name: <br>
  <input type='text' name='RName'><br>
    Restaurant Type: <br>
  <form action = 'EditingInfo.php' method='GET'>"
        . $restaurantController->CreateEditDropdownList('types') . " <br>
    Restaurant URL: <br>
  <input type='text' name='URL'> <br>
  <input type = 'submit' value = 'Add' name = 'AddRestaurant'>
</form></fieldset>
<fieldset name='types'>
Removing a Restaurant:  <br>
    <br>
   <form action = 'EditingInfo.php' method='GET'>"
        . $restaurantController->CreateEditDropdownList('names') . "
   <br> <input type = 'submit' value = 'Delete' name = 'RemoveRestaurant'>
   </form></fieldset>




";
}


include 'Template.php';
?>