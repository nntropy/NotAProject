<?php
require_once("C:\Users\aidanocc\Mitchell\Controller\RestaurantController.php");
$title = "Restaurants!";

$restaurantController = new RestaurantController();
$restaurantTable = '';
$i = 1;
$array = [];
while ($i < 10) {
    if (isset($_GET['interest' . (string)$i])) {
        array_push($array, $_GET['interest' . (string)$i]);
}
    $i++;
}

foreach ($array as $key => $type) {
    $restaurantTable .= $restaurantController->CreateRestaurantTables($type);
}
//Page loaded for first time, fill with all

if ($restaurantTable == '') {
    $restaurantTable = $restaurantController->CreateRestaurantTables('%');
}
$content = $restaurantTable;
$sidebar = $restaurantController->CreateRestaurantDropdownList();
//$content .=
include 'Template.php';
?>
